import { type RootConfigService } from '@backstage/backend-plugin-api';
/**
 * Client for the SRE runtime's read-only management API.
 *
 * The portal is the management plane and the runtime is the execution plane;
 * they talk over this API rather than sharing a process. That keeps the
 * canonical Agent schema and every authorization decision in the runtime, so
 * Backstage cannot become a second source of truth or a way around the
 * runtime's enforcement.
 */
export interface RuntimeManagementClient {
    readonly configured: boolean;
    get<T>(path: string): Promise<T>;
    /** bytes, for assets that must not go through JSON */
    getBinary(path: string): Promise<{
        status: number;
        contentType: string;
        bytes: Buffer;
    } | undefined>;
    post<T>(path: string, body: unknown): Promise<{
        status: number;
        body: T;
    }>;
}
export interface RuntimeOidcSettings {
    tokenUrl: string;
    clientId: string;
    clientSecret: string;
    username: string;
    password: string;
}
export interface RuntimeManagementClientOptions {
    baseUrl?: string;
    token?: string;
    oidc?: RuntimeOidcSettings;
    /**
     * LOCAL ONLY: the runtime's mock-OIDC minting route (`/dev/token/alice`).
     * A pasted dev token expires in an hour and dies with every runtime restart,
     * so the backend mints and refreshes its own, exactly as it does with real
     * OIDC. The runtime registers that route only when SRE_ENV=local.
     */
    devTokenUrl?: string;
}
/**
 * Read the optional runtime connection without making an empty YAML object
 * mandatory. Backstage keeps the `oidc` object when all of its environment
 * placeholders are unset, so checking only `getOptionalConfig()` would turn a
 * deliberately unconfigured local backend into a startup failure.
 *
 * A partially configured credential is different: silently ignoring it would
 * make an operator believe OIDC is active when it is not, so that remains a
 * clear configuration error naming the missing fields.
 */
export declare function readRuntimeManagementClientOptions(config: RootConfigService): RuntimeManagementClientOptions;
export declare class HttpRuntimeManagementClient implements RuntimeManagementClient {
    #private;
    readonly configured: boolean;
    constructor(options: RuntimeManagementClientOptions);
    get<T>(path: string): Promise<T>;
    /**
     * Fetch bytes rather than JSON — an avatar is an image, and putting it
     * through `response.json()` would corrupt it while still looking like a
     * successful request.
     */
    getBinary(path: string): Promise<{
        status: number;
        contentType: string;
        bytes: Buffer;
    } | undefined>;
    post<T>(path: string, body: unknown): Promise<{
        status: number;
        body: T;
    }>;
}
export declare const runtimeManagementClientRef: import("@backstage/backend-plugin-api").ServiceRef<RuntimeManagementClient, "plugin", "singleton">;
