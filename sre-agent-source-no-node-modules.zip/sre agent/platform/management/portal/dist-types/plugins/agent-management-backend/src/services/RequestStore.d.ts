import type { AgentSummary, ChangeSetDiff, ManagementRequestDetail, ManagementRequestSummary } from '../api/generated-types';
import type { PullRequestState } from './GitOpsPublisher';
/**
 * MANAGEMENT REQUESTS: a platform change, traced like a run.
 *
 *   Run     = execution of a user question   (user → manager → specialist → tool → answer)
 *   Request = execution of a management change (user → portal → PR → merge → Argo → runtime → routable)
 *
 * The store keeps only what THIS plane did and observed: who asked for what,
 * whether the change-set rendered, whether the pull request opened, and the
 * provider's last answer about that pull request. Everything after the merge
 * is read from the runtime's reconciliation on every request and projected
 * onto the same `RunNode` event vocabulary Runs use — so there is no second
 * event log, no stored "status" that can drift from reality, and the console
 * renders both with one Flow and one Timeline.
 *
 * Nothing here is invented: a step that has not happened is emitted as
 * `pending` with the observed reason, and a signal the deployment cannot
 * observe says so rather than turning green.
 *
 * Two implementations. The in-memory one is bounded and loses everything on a
 * backend restart, which is survivable for a console but not for an audit
 * trail. `PostgresRequestStore` persists the record and appends what this plane
 * observed to the shared append-only event log, so a restart costs nothing.
 *
 * The interface is ASYNC because durability is: every call site already sits
 * inside an async handler, so awaiting costs nothing and pretending the write
 * had landed would cost the record.
 */
export type RequestType = ManagementRequestSummary['type'];
export type RequestStatus = ManagementRequestSummary['status'];
export interface RequestRecord {
    id: string;
    agentId: string;
    type: RequestType;
    requestedBy: string;
    createdAt: string;
    branch: string;
    effects: string[];
    /** the rendered configuration diff — YAML, never a credential */
    diff?: ChangeSetDiff;
    preparedAt?: string;
    /** safe message from the runtime's preview; the runtime redacts its own errors */
    prepareError?: string;
    publishedAt?: string;
    publishError?: string;
    /** the deployment has no Git credential wired; the reason is a config hint */
    notConfigured?: string;
    pullRequest?: {
        number: number;
        url?: string;
    };
    /** the provider's last answer; terminal states are cached so we stop asking */
    pullRequestState?: PullRequestState & {
        observedAt: string;
    };
}
export interface RequestStore {
    readonly mode: 'mock' | 'real';
    record(request: RequestRecord): Promise<void>;
    update(id: string, patch: Partial<RequestRecord>): Promise<RequestRecord | undefined>;
    list(): Promise<RequestRecord[]>;
    get(id: string): Promise<RequestRecord | undefined>;
}
export declare class InMemoryRequestStore implements RequestStore {
    #private;
    readonly mode: "mock";
    constructor(capacity?: number);
    record(request: RequestRecord): Promise<void>;
    update(id: string, patch: Partial<RequestRecord>): Promise<RequestRecord | undefined>;
    list(): Promise<RequestRecord[]>;
    get(id: string): Promise<RequestRecord | undefined>;
}
export declare function newRequestId(): string;
/**
 * What the runtime currently says, as fetched by the caller. `undefined` means
 * the runtime could not be asked — a different fact from "the agent is absent".
 */
export interface RuntimeSnapshot {
    loadedAt: string;
    configError?: string;
    agents: AgentSummary[];
}
export interface ProjectionInput {
    record: RequestRecord;
    /** provider state as of now, or an error message when the provider could not be asked */
    pullRequest?: PullRequestState | {
        error: string;
    };
    runtime?: RuntimeSnapshot | {
        error: string;
    };
}
/**
 * The projection. Pure, so the same inputs always give the same trace and a
 * test can hand it a literal.
 */
export declare function projectRequest(input: ProjectionInput): ManagementRequestDetail;
export declare function summarise(detail: ManagementRequestDetail): ManagementRequestSummary;
/**
 * A durable request, with the observations that explain it.
 *
 * TWO WRITES, TWO ROLES. The record says what was ASKED for and is mutable —
 * a pull request number arrives after the row exists. The events say what was
 * OBSERVED and are append-only, because a log that can be rewritten is not a
 * log. Collapsing them would force one of those two properties to give.
 *
 * ═══ THIS STORE GRANTS NOTHING ═══
 *
 * Nothing here decides whether an Agent may route. `projectRequest` reads the
 * runtime's live reconciliation on every call, so a request that once observed
 * ACTIVE cannot speak for the present. There is deliberately no status column
 * to drift, and no join from this table into a routing decision.
 *
 * The portal is a separate workspace from the runtime and cannot import
 * `@sre/events`, so the event shape is re-stated here. The SQL table and the
 * OpenAPI contract are what the two planes actually agree on — the same split
 * the generated API types already live with.
 */
export interface RequestEvent {
    eventId: string;
    type: string;
    outcome: 'pending' | 'ok' | 'failed';
    occurredAt: string;
    actor?: string;
    metadata?: Record<string, string | number | boolean>;
}
/**
 * Redact anything credential-shaped out of a message before it is STORED.
 *
 * A provider's error is quoted verbatim into `prepare_error` and
 * `publish_error`, and those columns are written before any event is appended —
 * so validating only at append left the credential sitting in the request row
 * while the audit event was the thing rejected. Scrubbing at the boundary puts
 * the check where the value first arrives.
 */
export declare function scrubMessage(message: string): string;
/**
 * The minimum this store needs from a database.
 *
 * Narrow on purpose: the plugin then owns no import of `pg`, and Backstage's
 * own configured connection can be adapted to it rather than a second pool
 * being opened beside the one the backend already manages.
 */
export interface SqlClient {
    query<T>(text: string, values?: unknown[]): Promise<{
        rows: T[];
        rowCount: number | null;
    }>;
    end(): Promise<void>;
}
/** Minimal shape of the Knex instance Backstage hands out. */
interface KnexLike {
    raw(sql: string, bindings?: readonly unknown[]): Promise<unknown>;
}
/**
 * Adapt Backstage's database service to `SqlClient`.
 *
 * `knex.raw` on PostgreSQL answers with `{ rows, rowCount }`, which is the
 * shape this store already speaks. Adapting rather than opening a second pool
 * keeps connection limits, credentials and lifecycle in one place — the
 * backend's.
 */
export declare function knexSqlClient(knex: KnexLike): SqlClient;
export declare class PostgresRequestStore implements RequestStore {
    #private;
    readonly mode: "real";
    constructor(sql: SqlClient, environment: string);
    record(request: RequestRecord): Promise<void>;
    update(id: string, patch: Partial<RequestRecord>): Promise<RequestRecord | undefined>;
    list(): Promise<RequestRecord[]>;
    get(id: string): Promise<RequestRecord | undefined>;
    /** Append one observation. Idempotent by `eventId`; a repeat is a no-op. */
    append(requestId: string, event: RequestEvent): Promise<boolean>;
    /** Every observation about one request, oldest first. */
    events(requestId: string): Promise<RequestEvent[]>;
}
export {};
