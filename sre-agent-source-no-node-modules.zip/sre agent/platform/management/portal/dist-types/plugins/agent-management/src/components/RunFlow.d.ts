import type { RunNode } from '../api/types';
export declare function RunFlow({ nodes, footer }: {
    nodes: RunNode[];
    footer?: string;
}): import("react").JSX.Element;
