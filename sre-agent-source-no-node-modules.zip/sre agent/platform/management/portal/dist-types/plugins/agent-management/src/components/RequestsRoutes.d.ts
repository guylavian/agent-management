/** Requests list plus the execution graph for one request — the Runs layout, for changes. */
export declare function RequestsRoutes(): import("react").JSX.Element;
