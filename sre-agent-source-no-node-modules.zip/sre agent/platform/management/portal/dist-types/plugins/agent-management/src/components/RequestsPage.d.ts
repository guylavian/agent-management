import { Tone } from './common';
import type { ManagementRequestSummary } from '../api/types';
/**
 * MANAGEMENT REQUESTS.
 *
 * The same execution-trace views as Runs — Flow, Timeline, a side panel per
 * event — over a different domain: a Run explains how an answer was produced,
 * a Request explains how a platform change was applied. The components are
 * shared, not copied; only the event kinds differ.
 *
 * Everything on this page is a projection of the pull request the provider
 * reports and the reconciliation the runtime reports. The browser computes
 * nothing about the deployment, and there is no stored status to go stale.
 */
type RequestStatus = ManagementRequestSummary['status'];
export declare function requestStatusTone(status: RequestStatus): Tone;
export declare function RequestsPage({ pollMs }?: {
    pollMs?: number;
}): import("react").JSX.Element;
export declare function RequestDetailPage({ requestId }: {
    requestId: string;
}): import("react").JSX.Element;
export {};
