/**
 * Agent Management portal.
 *
 * One page extension per sidebar section — Backstage derives the nav entry from
 * each page, so the product's own navigation is what the user sees rather than
 * a single "plugin" entry. `noHeader` keeps Backstage's default page chrome out
 * of the way so the product surface reads as its own application.
 */
export declare const overviewPage: import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
    kind: "page";
    name: "overview";
    config: {
        path: string | undefined;
        title: string | undefined;
    };
    configInput: {
        path?: string | undefined;
        title?: string | undefined;
    };
    output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
        optional: true;
    }>;
    inputs: {
        pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>, {
            singleton: false;
            optional: false;
            internal: false;
        }>;
    };
    params: {
        path: string;
        title?: string;
        icon?: import("@backstage/frontend-plugin-api").IconElement;
        loader?: () => Promise<import("react").JSX.Element>;
        routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
        noHeader?: boolean;
    };
}>;
export declare const agentsPage: import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
    kind: "page";
    name: "agents";
    config: {
        path: string | undefined;
        title: string | undefined;
    };
    configInput: {
        path?: string | undefined;
        title?: string | undefined;
    };
    output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
        optional: true;
    }>;
    inputs: {
        pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>, {
            singleton: false;
            optional: false;
            internal: false;
        }>;
    };
    params: {
        path: string;
        title?: string;
        icon?: import("@backstage/frontend-plugin-api").IconElement;
        loader?: () => Promise<import("react").JSX.Element>;
        routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
        noHeader?: boolean;
    };
}>;
/**
 * The Manager gets its own page, not a row in the Agents table: it is a
 * different document type with no identity, access or routing vocabulary, and
 * the Agents table's columns would all be blank for it.
 */
export declare const managerPage: import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
    kind: "page";
    name: "manager";
    config: {
        path: string | undefined;
        title: string | undefined;
    };
    configInput: {
        path?: string | undefined;
        title?: string | undefined;
    };
    output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
        optional: true;
    }>;
    inputs: {
        pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>, {
            singleton: false;
            optional: false;
            internal: false;
        }>;
    };
    params: {
        path: string;
        title?: string;
        icon?: import("@backstage/frontend-plugin-api").IconElement;
        loader?: () => Promise<import("react").JSX.Element>;
        routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
        noHeader?: boolean;
    };
}>;
export declare const createAgentPage: import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
    kind: "page";
    name: "create-agent";
    config: {
        path: string | undefined;
        title: string | undefined;
    };
    configInput: {
        path?: string | undefined;
        title?: string | undefined;
    };
    output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
        optional: true;
    }>;
    inputs: {
        pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>, {
            singleton: false;
            optional: false;
            internal: false;
        }>;
    };
    params: {
        path: string;
        title?: string;
        icon?: import("@backstage/frontend-plugin-api").IconElement;
        loader?: () => Promise<import("react").JSX.Element>;
        routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
        noHeader?: boolean;
    };
}>;
export declare const permissionsPage: import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
    kind: "page";
    name: "permissions";
    config: {
        path: string | undefined;
        title: string | undefined;
    };
    configInput: {
        path?: string | undefined;
        title?: string | undefined;
    };
    output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
        optional: true;
    }>;
    inputs: {
        pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>, {
            singleton: false;
            optional: false;
            internal: false;
        }>;
    };
    params: {
        path: string;
        title?: string;
        icon?: import("@backstage/frontend-plugin-api").IconElement;
        loader?: () => Promise<import("react").JSX.Element>;
        routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
        noHeader?: boolean;
    };
}>;
export declare const mcpServersPage: import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
    kind: "page";
    name: "mcp-servers";
    config: {
        path: string | undefined;
        title: string | undefined;
    };
    configInput: {
        path?: string | undefined;
        title?: string | undefined;
    };
    output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
        optional: true;
    }>;
    inputs: {
        pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>, {
            singleton: false;
            optional: false;
            internal: false;
        }>;
    };
    params: {
        path: string;
        title?: string;
        icon?: import("@backstage/frontend-plugin-api").IconElement;
        loader?: () => Promise<import("react").JSX.Element>;
        routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
        noHeader?: boolean;
    };
}>;
export declare const runsPage: import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
    kind: "page";
    name: "runs";
    config: {
        path: string | undefined;
        title: string | undefined;
    };
    configInput: {
        path?: string | undefined;
        title?: string | undefined;
    };
    output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
        optional: true;
    }>;
    inputs: {
        pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>, {
            singleton: false;
            optional: false;
            internal: false;
        }>;
    };
    params: {
        path: string;
        title?: string;
        icon?: import("@backstage/frontend-plugin-api").IconElement;
        loader?: () => Promise<import("react").JSX.Element>;
        routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
        noHeader?: boolean;
    };
}>;
/**
 * Requests sit beside Runs on purpose: a Run explains how an answer was
 * produced, a Request explains how a platform change was applied, and both are
 * the same execution-trace model with different domain events.
 */
export declare const requestsPage: import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
    kind: "page";
    name: "requests";
    config: {
        path: string | undefined;
        title: string | undefined;
    };
    configInput: {
        path?: string | undefined;
        title?: string | undefined;
    };
    output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
        optional: true;
    }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
        optional: true;
    }>;
    inputs: {
        pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>, {
            singleton: false;
            optional: false;
            internal: false;
        }>;
    };
    params: {
        path: string;
        title?: string;
        icon?: import("@backstage/frontend-plugin-api").IconElement;
        loader?: () => Promise<import("react").JSX.Element>;
        routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
        noHeader?: boolean;
    };
}>;
export declare const agentManagementPlugin: import("@backstage/frontend-plugin-api").OverridableFrontendPlugin<{
    root: import("@backstage/frontend-plugin-api").RouteRef<undefined>;
    agents: import("@backstage/frontend-plugin-api").RouteRef<undefined>;
    create: import("@backstage/frontend-plugin-api").RouteRef<undefined>;
    permissions: import("@backstage/frontend-plugin-api").RouteRef<undefined>;
    mcpServers: import("@backstage/frontend-plugin-api").RouteRef<undefined>;
    runs: import("@backstage/frontend-plugin-api").RouteRef<undefined>;
    requests: import("@backstage/frontend-plugin-api").RouteRef<undefined>;
}, {}, {
    "page:agent-management/agents": import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
        kind: "page";
        name: "agents";
        config: {
            path: string | undefined;
            title: string | undefined;
        };
        configInput: {
            path?: string | undefined;
            title?: string | undefined;
        };
        output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>;
        inputs: {
            pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
                optional: true;
            }>, {
                singleton: false;
                optional: false;
                internal: false;
            }>;
        };
        params: {
            path: string;
            title?: string;
            icon?: import("@backstage/frontend-plugin-api").IconElement;
            loader?: () => Promise<import("react").JSX.Element>;
            routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
            noHeader?: boolean;
        };
    }>;
    "page:agent-management/create-agent": import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
        kind: "page";
        name: "create-agent";
        config: {
            path: string | undefined;
            title: string | undefined;
        };
        configInput: {
            path?: string | undefined;
            title?: string | undefined;
        };
        output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>;
        inputs: {
            pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
                optional: true;
            }>, {
                singleton: false;
                optional: false;
                internal: false;
            }>;
        };
        params: {
            path: string;
            title?: string;
            icon?: import("@backstage/frontend-plugin-api").IconElement;
            loader?: () => Promise<import("react").JSX.Element>;
            routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
            noHeader?: boolean;
        };
    }>;
    "page:agent-management/manager": import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
        kind: "page";
        name: "manager";
        config: {
            path: string | undefined;
            title: string | undefined;
        };
        configInput: {
            path?: string | undefined;
            title?: string | undefined;
        };
        output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>;
        inputs: {
            pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
                optional: true;
            }>, {
                singleton: false;
                optional: false;
                internal: false;
            }>;
        };
        params: {
            path: string;
            title?: string;
            icon?: import("@backstage/frontend-plugin-api").IconElement;
            loader?: () => Promise<import("react").JSX.Element>;
            routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
            noHeader?: boolean;
        };
    }>;
    "page:agent-management/mcp-servers": import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
        kind: "page";
        name: "mcp-servers";
        config: {
            path: string | undefined;
            title: string | undefined;
        };
        configInput: {
            path?: string | undefined;
            title?: string | undefined;
        };
        output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>;
        inputs: {
            pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
                optional: true;
            }>, {
                singleton: false;
                optional: false;
                internal: false;
            }>;
        };
        params: {
            path: string;
            title?: string;
            icon?: import("@backstage/frontend-plugin-api").IconElement;
            loader?: () => Promise<import("react").JSX.Element>;
            routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
            noHeader?: boolean;
        };
    }>;
    "page:agent-management/overview": import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
        kind: "page";
        name: "overview";
        config: {
            path: string | undefined;
            title: string | undefined;
        };
        configInput: {
            path?: string | undefined;
            title?: string | undefined;
        };
        output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>;
        inputs: {
            pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
                optional: true;
            }>, {
                singleton: false;
                optional: false;
                internal: false;
            }>;
        };
        params: {
            path: string;
            title?: string;
            icon?: import("@backstage/frontend-plugin-api").IconElement;
            loader?: () => Promise<import("react").JSX.Element>;
            routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
            noHeader?: boolean;
        };
    }>;
    "page:agent-management/permissions": import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
        kind: "page";
        name: "permissions";
        config: {
            path: string | undefined;
            title: string | undefined;
        };
        configInput: {
            path?: string | undefined;
            title?: string | undefined;
        };
        output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>;
        inputs: {
            pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
                optional: true;
            }>, {
                singleton: false;
                optional: false;
                internal: false;
            }>;
        };
        params: {
            path: string;
            title?: string;
            icon?: import("@backstage/frontend-plugin-api").IconElement;
            loader?: () => Promise<import("react").JSX.Element>;
            routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
            noHeader?: boolean;
        };
    }>;
    "page:agent-management/requests": import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
        kind: "page";
        name: "requests";
        config: {
            path: string | undefined;
            title: string | undefined;
        };
        configInput: {
            path?: string | undefined;
            title?: string | undefined;
        };
        output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>;
        inputs: {
            pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
                optional: true;
            }>, {
                singleton: false;
                optional: false;
                internal: false;
            }>;
        };
        params: {
            path: string;
            title?: string;
            icon?: import("@backstage/frontend-plugin-api").IconElement;
            loader?: () => Promise<import("react").JSX.Element>;
            routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
            noHeader?: boolean;
        };
    }>;
    "page:agent-management/runs": import("@backstage/frontend-plugin-api").OverridableExtensionDefinition<{
        kind: "page";
        name: "runs";
        config: {
            path: string | undefined;
            title: string | undefined;
        };
        configInput: {
            path?: string | undefined;
            title?: string | undefined;
        };
        output: import("@backstage/frontend-plugin-api").ExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<string, "core.title", {
            optional: true;
        }> | import("@backstage/frontend-plugin-api").ExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
            optional: true;
        }>;
        inputs: {
            pages: import("@backstage/frontend-plugin-api").ExtensionInput<import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("react").JSX.Element, "core.reactElement", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.routing.path", {}> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").RouteRef<import("@backstage/frontend-plugin-api").AnyRouteRefParams>, "core.routing.ref", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<string, "core.title", {
                optional: true;
            }> | import("@backstage/frontend-plugin-api").ConfigurableExtensionDataRef<import("@backstage/frontend-plugin-api").IconElement, "core.icon", {
                optional: true;
            }>, {
                singleton: false;
                optional: false;
                internal: false;
            }>;
        };
        params: {
            path: string;
            title?: string;
            icon?: import("@backstage/frontend-plugin-api").IconElement;
            loader?: () => Promise<import("react").JSX.Element>;
            routeRef?: import("@backstage/frontend-plugin-api").RouteRef;
            noHeader?: boolean;
        };
    }>;
}>;
