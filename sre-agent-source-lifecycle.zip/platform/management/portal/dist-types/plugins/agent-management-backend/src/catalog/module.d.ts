/**
 * Registers Agents and their MCP dependencies in the Backstage catalog,
 * derived from the canonical Agent definitions the runtime loads.
 *
 * @public
 */
export declare const catalogModuleSreAgents: import("@backstage/backend-plugin-api").BackendFeature;
