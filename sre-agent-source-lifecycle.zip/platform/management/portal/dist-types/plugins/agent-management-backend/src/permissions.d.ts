/**
 * Management-plane permissions (TDD §40).
 *
 * These govern WHO MAY MANAGE an Agent. They are a completely different
 * authorization domain from Agent → MCP → Tool: holding `agent.access.edit`
 * lets a human propose a policy change, it never grants an Agent access to
 * anything. The runtime remains the only authority for what an Agent may call.
 */
export declare const agentReadPermission: import("@backstage/plugin-permission-common").BasicPermission;
export declare const agentCreatePermission: import("@backstage/plugin-permission-common").BasicPermission;
export declare const agentEditPermission: import("@backstage/plugin-permission-common").BasicPermission;
export declare const agentDisablePermission: import("@backstage/plugin-permission-common").BasicPermission;
export declare const agentPromptEditPermission: import("@backstage/plugin-permission-common").BasicPermission;
export declare const agentAccessEditPermission: import("@backstage/plugin-permission-common").BasicPermission;
export declare const agentToolsEditPermission: import("@backstage/plugin-permission-common").BasicPermission;
export declare const agentCreatePrPermission: import("@backstage/plugin-permission-common").BasicPermission;
export declare const mcpReadPermission: import("@backstage/plugin-permission-common").BasicPermission;
export declare const runReadPermission: import("@backstage/plugin-permission-common").BasicPermission;
export declare const evaluationReadPermission: import("@backstage/plugin-permission-common").BasicPermission;
export declare const agentManagementPermissions: import("@backstage/plugin-permission-common").BasicPermission[];
