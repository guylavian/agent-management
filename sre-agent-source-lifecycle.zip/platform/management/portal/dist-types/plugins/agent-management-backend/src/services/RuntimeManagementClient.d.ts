/**
 * Client for the SRE runtime's read-only management API.
 *
 * The portal is the management plane and the runtime is the execution plane;
 * they talk over this API rather than sharing a process. That keeps the
 * canonical Agent schema and every authorization decision in the runtime, so
 * Backstage cannot become a second source of truth or a way around the
 * runtime's enforcement.
 */
export interface RuntimeManagementClient {
    readonly configured: boolean;
    get<T>(path: string): Promise<T>;
    /** bytes, for assets that must not go through JSON */
    getBinary(path: string): Promise<{
        status: number;
        contentType: string;
        bytes: Buffer;
    } | undefined>;
    post<T>(path: string, body: unknown): Promise<{
        status: number;
        body: T;
    }>;
}
export interface RuntimeOidcSettings {
    tokenUrl: string;
    clientId: string;
    clientSecret: string;
    username: string;
    password: string;
}
export declare class HttpRuntimeManagementClient implements RuntimeManagementClient {
    #private;
    readonly configured: boolean;
    constructor(options: {
        baseUrl?: string;
        token?: string;
        oidc?: RuntimeOidcSettings;
    });
    get<T>(path: string): Promise<T>;
    /**
     * Fetch bytes rather than JSON — an avatar is an image, and putting it
     * through `response.json()` would corrupt it while still looking like a
     * successful request.
     */
    getBinary(path: string): Promise<{
        status: number;
        contentType: string;
        bytes: Buffer;
    } | undefined>;
    post<T>(path: string, body: unknown): Promise<{
        status: number;
        body: T;
    }>;
}
export declare const runtimeManagementClientRef: import("@backstage/backend-plugin-api").ServiceRef<RuntimeManagementClient, "plugin", "singleton">;
