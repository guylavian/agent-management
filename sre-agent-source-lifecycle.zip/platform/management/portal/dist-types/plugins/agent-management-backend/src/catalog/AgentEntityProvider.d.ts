import type { EntityProvider, EntityProviderConnection } from '@backstage/plugin-catalog-node';
import type { LoggerService, SchedulerService } from '@backstage/backend-plugin-api';
import type { RuntimeManagementClient } from '../services/RuntimeManagementClient';
/**
 * Derives Backstage catalog entities from the canonical Agent definitions
 * (TDD §42).
 *
 * Entities come from the runtime's projection of `config/agents/*.yaml` rather
 * than a second hand-maintained catalog-info file, so the catalog cannot disagree with
 * what the runtime actually enforces. Agents are emitted as Components owned by
 * their team, each depending on the MCP Resources it is allowed to reach.
 */
export declare class AgentEntityProvider implements EntityProvider {
    #private;
    private readonly runtime;
    private readonly logger;
    private readonly scheduler;
    private readonly frequencyMinutes;
    constructor(runtime: RuntimeManagementClient, logger: LoggerService, scheduler: SchedulerService, frequencyMinutes?: number);
    getProviderName(): string;
    connect(connection: EntityProviderConnection): Promise<void>;
    refresh(): Promise<void>;
}
