import type { GitOpsPublisher, PullRequestInput, PullRequestOutcome } from './GitOpsPublisher';
/**
 * Opens the Agent change pull request on BITBUCKET DATA CENTER (Bitbucket
 * Server), the enterprise on-prem Git host.
 *
 * This exists because the platform's only Git write path was Octokit, and
 * Octokit speaks one API. An air-gapped datacenter with Bitbucket Data Center
 * could deploy every other part of this product and still have a console whose
 * "propose change" button could not work — the one feature that makes the
 * management plane more than a viewer.
 *
 * Written against `fetch` rather than a Bitbucket client library on purpose:
 * four endpoints, no new dependency to vendor into an offline npm mirror, and
 * no transitive package that might decide to phone home.
 *
 * ADDRESSING IS NOT GITHUB'S. Bitbucket names a repository by PROJECT KEY plus
 * slug, not owner plus name, and its REST base is `/rest/api/1.0` with branch
 * creation living under a SEPARATE `/rest/branch-utils/1.0` base. Those are the
 * details that make "just swap the base URL" produce 404s.
 */
export interface BitbucketServerGitOpsSettings {
    /** e.g. https://bitbucket.internal.example — no path, no trailing slash */
    baseUrl: string;
    /** the PROJECT KEY (e.g. SRE), not the project's display name */
    project: string;
    /** the repository slug */
    repo: string;
    baseBranch: string;
    /** HTTP access token with repository write; sent as a bearer token */
    token: string;
}
export declare class BitbucketServerGitOpsPublisher implements GitOpsPublisher {
    #private;
    readonly configured = true;
    constructor(settings: BitbucketServerGitOpsSettings, fetchImpl?: typeof fetch);
    createPullRequest(input: PullRequestInput): Promise<PullRequestOutcome>;
}
