import { type RootConfigService } from '@backstage/backend-plugin-api';
import { Octokit } from '@octokit/rest';
/**
 * Opens the pull request that changes an Agent.
 *
 * This lives in the MANAGEMENT plane, not the runtime. Before, the portal asked
 * the runtime to open the PR, which meant the execution plane held a Git write
 * token — a credential the request path has no use for, on the one process that
 * must not be able to change its own policy.
 *
 *   portal → Backstage backend → Git provider → pull request
 *
 * The runtime still owns the canonical Agent SCHEMA and renders the change-set,
 * because it is the thing that must load the result at startup. It just no
 * longer performs the write. Its `/management/agents/preview` is pure.
 *
 * Credentials come from Backstage's own SCM integrations, so the token is
 * configured once, in the place Backstage already expects it, and never appears
 * in this plugin's config.
 */
export interface ChangedFile {
    path: string;
    contents: string;
    /**
     * `base64` when `contents` carries bytes rather than text.
     *
     * Without this the encode below treats an image as UTF-8 and commits a
     * corrupted file that still looks like a successful pull request. An avatar
     * is the first binary file this platform writes, so the encoding travels with
     * the file rather than being guessed from its extension.
     */
    encoding?: 'base64';
}
export interface PullRequestInput {
    branch: string;
    title: string;
    body: string;
    files: ChangedFile[];
}
export interface PullRequestOutcome {
    status: 'created' | 'not-configured';
    url?: string;
    number?: number;
    reason?: string;
}
/**
 * An Agent that has been PROPOSED but not merged.
 *
 * Only the management plane can see one. The runtime reads the repository as
 * Argo synced it, so an open branch does not exist to it at all — which is why
 * "Pending merge" could previously only be a badge on the page that had just
 * opened the pull request, and vanished the moment the operator navigated away.
 *
 * The agent id is recovered from the BRANCH, which the runtime derives from the
 * agent name (`agent/add-<name>`). That is the only part of a proposal this
 * plane may read: opening the diff to parse the YAML would put the canonical
 * Agent schema in the management plane, which is the boundary the whole design
 * keeps.
 */
export interface AgentProposal {
    agentId: string;
    /** "add" or "update" — an update is a change to an Agent that already exists */
    kind: 'add' | 'update';
    branch: string;
    title: string;
    url?: string;
    number?: number;
}
export interface GitOpsPublisher {
    readonly configured: boolean;
    createPullRequest(input: PullRequestInput): Promise<PullRequestOutcome>;
    /**
     * Open Agent proposals, or an empty list when this deployment has no Git
     * credential. Empty is honest here: with no credential nothing was observed,
     * and the console says so at the page level rather than per row.
     */
    listProposals(): Promise<AgentProposal[]>;
}
/** `agent/add-kafka` → kafka. Anything else on the branch list is not ours. */
export declare function proposalFromBranch(branch: string, title: string, extra?: {
    url?: string;
    number?: number;
}): AgentProposal | undefined;
export interface GitHubGitOpsSettings {
    owner: string;
    repo: string;
    baseBranch: string;
    token: string;
    apiBaseUrl?: string;
}
/**
 * Reports "not configured" rather than pretending. A portal that shows a
 * success state for a pull request that does not exist is worse than one that
 * says it cannot open one.
 */
export declare class UnconfiguredGitOpsPublisher implements GitOpsPublisher {
    #private;
    readonly configured = false;
    constructor(reason: string);
    createPullRequest(): Promise<PullRequestOutcome>;
    listProposals(): Promise<AgentProposal[]>;
}
export declare class GitHubGitOpsPublisher implements GitOpsPublisher {
    #private;
    readonly configured = true;
    constructor(settings: GitHubGitOpsSettings, octokit?: Octokit);
    createPullRequest(input: PullRequestInput): Promise<PullRequestOutcome>;
    listProposals(): Promise<AgentProposal[]>;
}
export interface BitbucketServerGitOpsSettings {
    /** Bitbucket Server project KEY (the `owner` config key, reused across providers) */
    projectKey: string;
    /** repository slug */
    repo: string;
    baseBranch: string;
    token: string;
    /** e.g. https://bitbucket.company.com/rest/api/1.0 — from the SCM integration */
    apiBaseUrl: string;
}
/**
 * Bitbucket Server / Data Center. Same contract, different provider grammar:
 * project key + repository slug instead of owner/repo, `/rest/api/1.0` instead
 * of the Cloud 2.0 API (which is why the Cloud-oriented `bitbucket` npm client
 * is not used here), and a 409 where GitHub answers 422.
 *
 * The amendment path is deliberately identical in behaviour to the GitHub
 * publisher: the branch name derives from the agent, so the second proposal for
 * an agent lands on an existing branch with an open pull request — that is the
 * normal case, and the open PR (which now shows the new files) is the truthful
 * answer.
 */
export declare class BitbucketServerGitOpsPublisher implements GitOpsPublisher {
    #private;
    readonly configured = true;
    constructor(settings: BitbucketServerGitOpsSettings, fetchImplementation?: typeof fetch);
    createPullRequest(input: PullRequestInput): Promise<PullRequestOutcome>;
    listProposals(): Promise<AgentProposal[]>;
}
export declare const gitOpsPublisherRef: import("@backstage/backend-plugin-api").ServiceRef<GitOpsPublisher, "plugin", "singleton">;
export declare function fromConfig(config: RootConfigService): GitOpsPublisher;
