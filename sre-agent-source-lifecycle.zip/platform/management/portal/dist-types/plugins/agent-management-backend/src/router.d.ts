import type { HttpAuthService, PermissionsService } from '@backstage/backend-plugin-api';
import express from 'express';
import { runtimeManagementClientRef } from './services/RuntimeManagementClient';
import type { gitOpsPublisherRef } from './services/GitOpsPublisher';
/**
 * Management operations for the portal.
 *
 * Every route is permission-checked for the HUMAN performing it, then proxied
 * to the runtime's management API. Backstage authorizing a human to edit an
 * Agent says nothing about what that Agent may call — those decisions stay in
 * the runtime and are re-evaluated there on every tool call (TDD §41).
 */
export declare function createRouter({ httpAuth, permissions, runtime, gitops, }: {
    httpAuth: HttpAuthService;
    permissions: PermissionsService;
    runtime: typeof runtimeManagementClientRef.T;
    gitops: typeof gitOpsPublisherRef.T;
}): Promise<express.Router>;
