/**
 * Agent management backend plugin.
 *
 * Provides the portal's management operations and registers the management
 * permissions. It reads the runtime's read-only management API and never
 * enforces runtime tool access itself.
 *
 * It also owns the WRITE path: the runtime renders a change-set, this plugin
 * opens the pull request. The execution plane holds no Git credential, so it
 * cannot change the policy it enforces.
 *
 * @public
 */
export declare const agentManagementPlugin: import("@backstage/backend-plugin-api").BackendFeature;
