import type { CSSProperties, ReactNode, KeyboardEvent } from 'react';
import type { AgentLifecycle, AgentReconciliation, AgentStatus, Signal, ToolClassification } from '../api/types';
/**
 * Makes a non-semantic element operable by keyboard as well as mouse.
 *
 * These rows, cells and breadcrumbs are styled containers rather than
 * `<button>`s, which is a visual choice — it must not become an accessibility
 * one. Spreading this gives them a role, focus order and Enter/Space handling,
 * so nothing in the console is reachable only with a pointer.
 */
export declare function clickable(onClick: () => void): {
    readonly role: "button";
    readonly tabIndex: 0;
    readonly onClick: () => void;
    readonly onKeyDown: (event: KeyboardEvent<HTMLElement>) => void;
};
/**
 * Design system for the Agent Management console.
 *
 * The audience is platform and SRE engineers reading configuration, so the
 * surface is built for density and scanning: flat panels, thin rules, one
 * accent colour, and colour reserved for meaning. Nothing here is decorative.
 *
 * COLOUR IS FUNCTIONAL. green = healthy, amber = degraded or pending, red =
 * failed or denied, blue = link, selection or primary action. Everything else
 * is neutral grey. An operator scanning a table should be able to trust that a
 * coloured pixel means something.
 *
 * Styles are plain inline objects so the plugin carries no styling dependency
 * and Backstage's own theme cannot bleed into the product surface.
 */
/** 4 / 8 / 12 / 16 / 24 / 32. Every gap, pad and margin comes from here. */
export declare const S: {
    readonly xs: 4;
    readonly sm: 8;
    readonly md: 12;
    readonly lg: 16;
    readonly xl: 24;
    readonly xxl: 32;
};
/** Containers are softened; controls stay tighter so forms still read as forms. */
export declare const R: {
    readonly control: 8;
    readonly container: 12;
    readonly small: 6;
};
export declare const C: {
    accent: string;
    accentHover: string;
    accentSoft: string;
    /**
     * Cool near-white. An earlier pass warmed this to a beige and the result read
     * as a dirty grey rather than as warmth: the surfaces sitting on it are pure
     * white, and the two fought. Warmth here comes from roundness, space and
     * illustration, not from tinting the paper.
     */
    canvas: string;
    surface: string;
    /** the rail is WHITE and separated by a rule, as the reference has it */
    rail: string;
    hover: string;
    border: string;
    borderInput: string;
    borderStrong: string;
    rule: string;
    ruleSoft: string;
    chip: string;
    text: string;
    body: string;
    bodySoft: string;
    muted: string;
    faint: string;
    dim: string;
    green: string;
    greenBright: string;
    greenSoft: string;
    amber: string;
    amberBright: string;
    amberSoft: string;
    red: string;
    redBright: string;
    redSoft: string;
};
export declare function tileTone(owner: string): {
    bg: string;
    fg: string;
};
/** First letters of an owner or agent id, for the tile. Never a person. */
export declare function initials(name: string): string;
export declare const FONT = "'Figtree',Helvetica,Arial,sans-serif";
export declare const MONO = "ui-monospace,Menlo,monospace";
export declare function Page(props: {
    children: ReactNode;
}): import("react").JSX.Element;
export declare function PageHeader(props: {
    title: string;
    subtitle?: string;
    action?: ReactNode;
    tight?: boolean;
}): import("react").JSX.Element;
export declare function Breadcrumb(props: {
    items: Array<{
        label: string;
        onClick?: () => void;
    }>;
}): import("react").JSX.Element;
export declare function Button(props: {
    onClick?: () => void;
    variant?: 'primary' | 'secondary' | 'link';
    disabled?: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
/**
 * A single counted fact. Deliberately small: these are reference numbers an
 * operator glances at, not a dashboard, so the value does not dominate the row.
 */
export declare function StatCard(props: {
    label: string;
    value: ReactNode;
    sub?: ReactNode;
    dot?: string;
    subTone?: 'default' | 'ok';
}): import("react").JSX.Element;
/**
 * Small monochrome line icons, drawn inline.
 *
 * `@material-ui/icons` is a dependency of the app shell but not of this plugin,
 * and a handful of 16px strokes is not worth taking one on. They inherit
 * `currentColor`, so a section heading and its icon can never disagree.
 */
export declare function Icon(props: {
    name: keyof typeof ICON_PATHS;
    size?: number;
    color?: string;
}): import("react").JSX.Element;
declare const ICON_PATHS: {
    readonly overview: import("react").JSX.Element;
    readonly agents: import("react").JSX.Element;
    readonly manager: import("react").JSX.Element;
    readonly mcp: import("react").JSX.Element;
    readonly permissions: import("react").JSX.Element;
    readonly runs: import("react").JSX.Element;
    readonly catalog: import("react").JSX.Element;
    readonly settings: import("react").JSX.Element;
    readonly general: import("react").JSX.Element;
    readonly routing: import("react").JSX.Element;
    readonly model: import("react").JSX.Element;
    readonly identity: import("react").JSX.Element;
    readonly runtime: import("react").JSX.Element;
    readonly security: import("react").JSX.Element;
    readonly tool: import("react").JSX.Element;
    readonly activity: import("react").JSX.Element;
};
/**
 * A soft container. Used where a group of facts belongs together — a section of
 * a form, an agent in a grid. `interactive` adds the one-pixel lift that says
 * a whole surface is clickable; nothing else in the console moves on hover.
 */
export declare function Card(props: {
    onClick?: () => void;
    padded?: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
/**
 * The small visual area on an agent card: initials of the agent id on a tone
 * chosen by OWNER. It represents a service, never a person — there are no
 * photographs and no invented identities anywhere in this console.
 */
/**
 * The agent's mark: its image when it has one, its initials when it does not.
 *
 * The fallback is not a placeholder to be replaced later — most agents will
 * never have an image, and initials on the owning team's tone is the finished
 * state for them. A failed load falls back too, so a missing or corrupt asset
 * degrades to the same thing rather than to a broken-image icon.
 */
export declare function AgentTile(props: {
    id: string;
    owner: string;
    size?: number;
    avatar?: {
        asset: string;
        fit: 'cover' | 'contain';
    };
}): import("react").JSX.Element;
/** Section heading with an optional icon, for a page built from Cards. */
export declare function GroupHeader(props: {
    title: string;
    icon?: keyof typeof ICON_PATHS;
    action?: ReactNode;
}): import("react").JSX.Element;
/**
 * A blue-tinted chip for a single standing fact — read-only, granted. Small,
 * and only ever one per surface: it is the exception, not a row of labels.
 */
export declare function SoftChip(props: {
    children: ReactNode;
}): import("react").JSX.Element;
/**
 * The card an agent gets in a grid: a tinted initials tile, the name, its
 * status, the description from its own document, and what it can reach.
 *
 * The reference this follows puts an illustration and a person's face on each
 * card. There is no illustration in the Agent document and no person anywhere
 * in this system — the runtime hashes the subject before it leaves — so the
 * tile is initials on a tone chosen by owning team, and the byline is the team.
 */
export declare function AgentGridCard(props: {
    id: string;
    displayName: string;
    description?: string;
    owner: string;
    lifecycle: AgentLifecycle;
    mcpCount: number;
    toolCount: number;
    readOnly: boolean;
    /** the MANAGED status; the document's lifecycle is a fallback, not a synonym */
    reconciliation?: AgentReconciliation;
    avatar?: {
        asset: string;
        fit: 'cover' | 'contain';
    };
    onOpen: () => void;
}): import("react").JSX.Element;
/**
 * A modal for one focused sub-task — picking the tools on a single MCP server.
 *
 * Closing is possible from three places (the button, the backdrop, Escape)
 * because a dialog that traps an operator is worse than one that is easy to
 * dismiss by accident: nothing here is destructive, and every selection is
 * still only a draft until a pull request is merged.
 */
export declare function Dialog(props: {
    title: string;
    subtitle?: string;
    onClose: () => void;
    children: ReactNode;
}): import("react").JSX.Element;
/** Relative time from an ISO timestamp. Real value or nothing — never "just now" as filler. */
export declare function relativeTime(iso: string): string;
export declare function StatGrid(props: {
    columns?: number;
    children: ReactNode;
}): import("react").JSX.Element;
/** Flat surface with an optional titled header rule. */
export declare function Panel(props: {
    title?: string;
    action?: ReactNode;
    padded?: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
/**
 * A titled band on a long configuration page — the unit the Create Agent form
 * is built from. Sections are separated by a rule and a heading rather than by
 * nesting one card inside another, which reads as depth that is not there.
 */
export declare function Section(props: {
    title: string;
    description?: string;
    icon?: keyof typeof ICON_PATHS;
    children: ReactNode;
}): import("react").JSX.Element;
/**
 * The agent grid.
 *
 * `auto-fit` rather than `auto-fill`: when there are fewer agents than the row
 * could hold, auto-fill leaves the surplus tracks standing and the cards sit
 * narrow against dead space, while auto-fit collapses them so the cards grow
 * into the width. That single word is the difference between a fluid workspace
 * and a fixed grid centred in a large screen.
 */
export declare const AGENT_GRID: CSSProperties;
/** Two-column field grid: the default arrangement inside a Section. */
export declare function FieldGrid(props: {
    columns?: number;
    children: ReactNode;
}): import("react").JSX.Element;
/**
 * Tables are CSS grids, not <table>, so column tracks stay aligned across the
 * header rule and every row while cells remain free-form.
 */
export declare function DataTable(props: {
    columns: string;
    head: ReactNode[];
    children: ReactNode;
}): import("react").JSX.Element;
export declare function DataRow(props: {
    columns: string;
    onClick?: () => void;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function Muted(props: {
    size?: number;
    mono?: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function Body(props: {
    mono?: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
export type Tone = 'ok' | 'warn' | 'danger' | 'neutral' | 'info';
/**
 * Status as a coloured dot and a plain label — the console's most repeated
 * element, so it is also its quietest. A filled capsule per row turns a table
 * into a field of colour and makes the one row that is actually degraded
 * harder to find, not easier.
 */
export declare function StatusPill(props: {
    tone: Tone;
    dot?: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
/** A bounded label for an identifier — model profile, audience, scope. */
export declare function Chip(props: {
    mono?: boolean;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function lifecycleTone(lifecycle: AgentLifecycle): Tone;
export declare function LifecycleBadge({ lifecycle }: {
    lifecycle: AgentLifecycle;
}): import("react").JSX.Element;
/**
 * READ / WRITE / UNKNOWN. UNKNOWN is rendered as a warning and never as READ —
 * a tool missing from the approved catalog must look unsafe, because it is.
 * This one keeps a filled background: it marks the two values an operator must
 * not skim past, and READ is the overwhelmingly common case it contrasts with.
 */
export declare function ModeBadge({ classification }: {
    classification: ToolClassification;
}): import("react").JSX.Element;
export declare function Allowed({ value }: {
    value: boolean;
}): import("react").JSX.Element;
export declare function Toggle(props: {
    on: boolean;
    onClick?: () => void;
    label?: string;
}): import("react").JSX.Element;
export declare function Tabs(props: {
    tabs: readonly string[];
    active: string;
    onChange: (tab: string) => void;
}): import("react").JSX.Element;
export declare const inputStyle: CSSProperties;
export declare const selectStyle: CSSProperties;
export declare function Field(props: {
    label: string;
    hint?: string;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function DefinitionList(props: {
    items: Array<[string, ReactNode]>;
    columns?: string;
}): import("react").JSX.Element;
export declare function Mono(props: {
    children: ReactNode;
}): import("react").JSX.Element;
export declare function SectionTitle(props: {
    children: ReactNode;
}): import("react").JSX.Element;
/**
 * Separates "not wired up" from "empty" and from "broken". An empty console for
 * an unconfigured backend would read as a true statement about the platform.
 */
export declare function AsyncState(props: {
    loading: boolean;
    error?: Error;
    children: ReactNode;
}): import("react").JSX.Element;
/** Compact by design: nothing to show should not occupy the room of something. */
export declare function EmptyState(props: {
    children: ReactNode;
}): import("react").JSX.Element;
/** Run status → tone. Named because it is used on four screens and read at a glance. */
export declare function runStatusTone(status: string): 'ok' | 'warn' | 'danger';
/** Run status → dot colour, the same mapping in the palette's terms. */
export declare function runStatusColor(status: string): string;
/**
 * RECONCILIATION, RENDERED.
 *
 * Git is desired state; Argo CD and the pod are actual state. The console keeps
 * them apart because "merged but not synced", "synced but not ready" and "ready
 * but not routable" are three different problems, and one green dot for all of
 * them tells an operator only that today is going badly.
 */
export declare function reconciliationTone(status: AgentStatus): Tone;
/**
 * The status badge. An Agent with no reconciliation block is reported as such
 * rather than defaulting to a colour: the backend could not compute it, and
 * "unknown" is the honest answer to a question nobody managed to ask.
 */
export declare function ReconciliationBadge({ reconciliation }: {
    reconciliation?: AgentReconciliation;
}): import("react").JSX.Element;
/**
 * The first signal that is not fine, in the order an operator would check them:
 * a card has room for ONE sentence, and "Argo is degraded" is more use on it
 * than "the Manager cannot route to this", which is only the consequence.
 */
export declare function blockingSignal(reconciliation: AgentReconciliation): Signal;
/**
 * The four signals, each with the reason it is in the state it is in.
 *
 * Every row carries `detail`, because a red cross with no sentence next to it
 * sends someone to the logs to discover what this page already knew.
 */
export declare function ReconciliationPanel({ reconciliation }: {
    reconciliation?: AgentReconciliation;
}): import("react").JSX.Element;
export {};
