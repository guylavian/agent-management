import type { ManagerDetail } from '../api/types';
/**
 * The Manager view as this console needs it, from whatever the runtime sent.
 *
 * The runtime is a SEPARATE PROCESS on its own release cadence, so the console
 * will meet one that predates a contract change — during a rollout, that is the
 * normal state for minutes at a time. Reading `manager.routable.length` from a
 * response that has no `routable` took the whole page down with a white screen,
 * which is the worst possible way to report "these two are different versions".
 *
 * Absent is NOT rendered as empty: an empty routing table and an unknown one
 * look identical on screen and mean opposite things, so `known` is false and
 * the page says which runtime it is talking to instead of implying the Manager
 * can route nowhere.
 */
interface ManagerView {
    routable: string[];
    notRouted: string[];
    environment: string;
    /** false when the runtime did not send a derived routing table at all */
    known: boolean;
}
export declare function managerView(manager: ManagerDetail): ManagerView;
/**
 * The Manager, which the console used to omit entirely — it is not in
 * `listSpecialists()`, so the Agents page could never show it, and the one Agent
 * deciding which specialist runs was the one Agent an operator could not see.
 *
 * It gets its own page rather than a row in the Agents table because it is a
 * different document type: no workload identity, no MCP access and no routing
 * vocabulary.
 *
 * Its routing table is READ-ONLY here, and that is the fix rather than a
 * limitation. It used to be a checkbox list backed by a hand-written
 * `agents.allowed` field, which meant onboarding an Agent took a second pull
 * request against this page that nothing checked anyone had made — and an Agent
 * could sit deployed and healthy while the Manager was never offered it. The
 * table is now DERIVED from each Agent's own lifecycle and deployment overlay,
 * so this page shows who is reachable and where to go to change it.
 */
export declare function ManagerPage(): import("react").JSX.Element;
export {};
