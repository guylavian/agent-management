import type { AgentDetail, AgentDraft, AgentSummary, ChangePreview, ManagerDetail, ManagerDraft, McpServer, PermissionMatrix, PromptAssistRequest, RunDetail, RunSummary } from './types';
/**
 * Thin client over the agent-management backend plugin.
 *
 * A 501 means the deployment has no runtime management API wired. That is
 * surfaced to the caller as `notConfigured` so pages can say so, rather than
 * rendering an empty table that looks like "you have no agents".
 */
export declare class NotConfiguredError extends Error {
    readonly reason: string;
    constructor(reason: string);
}
/**
 * How often views that track a RECONCILING resource re-fetch.
 *
 * Merging a pull request starts a sequence nobody drives from this browser:
 * Argo syncs, a pod starts, the Manager's catalog picks the Agent up. Without a
 * poll the console showed the state at page load and stayed there, so the only
 * way to see a merge take effect was to know to press reload — and an operator
 * watching a deployment that has silently failed will reload for a while before
 * they start to doubt the page instead of the deployment.
 *
 * Seven seconds is slower than the runtime's own desired-state revalidation, so
 * a poll costs a few `stat` calls rather than a re-validation of every Agent.
 */
export declare const RECONCILE_POLL_MS = 7000;
/**
 * `useAsync` that re-runs on a timer.
 *
 * The previous value stays on screen while the next request is in flight, so a
 * polling table does not flash its loading state every few seconds. A tab in
 * the background stops polling: `document.hidden` is checked on each tick
 * rather than by tearing the interval down, so returning to the tab refreshes
 * on the next tick instead of needing a remount.
 */
export declare function usePolled<T>(load: () => Promise<T>, deps: unknown[], intervalMs?: number): {
    value: T | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: T | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: T | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: T | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
};
/**
 * The Agents directory. Polled, because an Agent that merged a moment ago has
 * to appear on its own — the whole point of the flow is that merging is enough.
 */
export declare function useAgents(): {
    value: {
        agents: AgentSummary[];
        revision: string;
        configError?: string;
        proposalsError?: string;
    } | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: {
        agents: AgentSummary[];
        revision: string;
        configError?: string;
        proposalsError?: string;
    } | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: {
        agents: AgentSummary[];
        revision: string;
        configError?: string;
        proposalsError?: string;
    } | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: {
        agents: AgentSummary[];
        revision: string;
        configError?: string;
        proposalsError?: string;
    } | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
};
/** No id means nothing to fetch — the create wizard shares a component with the edit wizard. */
export declare function useAgent(id: string): {
    value: AgentDetail | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: AgentDetail | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: AgentDetail | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: AgentDetail | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
};
/** The Manager is its own endpoint because it is its own document type. */
export declare function useManager(): {
    value: ManagerDetail | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: ManagerDetail | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: ManagerDetail | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: ManagerDetail | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
};
export declare function useAgentHealth(id: string): {
    value: Record<string, unknown> | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: Record<string, unknown> | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: Record<string, unknown> | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: Record<string, unknown> | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
};
export declare function useAgentMetrics(id: string): import("react-use/esm/useAsyncFn").AsyncState<Record<string, unknown>>;
export declare function useMcpServers(): import("react-use/esm/useAsyncFn").AsyncState<McpServer[]>;
export declare function usePermissionMatrix(): import("react-use/esm/useAsyncFn").AsyncState<PermissionMatrix>;
export declare function useRuns(): {
    value: RunSummary[] | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: RunSummary[] | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: RunSummary[] | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
} | {
    value: RunSummary[] | undefined;
    loading: boolean;
    refreshing: boolean;
    error: Error | undefined;
    refreshError: Error | undefined;
};
export declare function useRun(id: string): import("react-use/esm/useAsyncFn").AsyncState<RunDetail>;
/**
 * Read a run's trace with the console-assistance model.
 *
 * Not a `useAsync`: a diagnosis costs a model call, so it happens when an
 * operator asks for one rather than on every visit to the page.
 */
export declare function useRunDiagnosis(): (id: string) => Promise<{
    diagnosis: string;
}>;
export declare function useEvaluations(): import("react-use/esm/useAsyncFn").AsyncState<Record<string, unknown>>;
/** Imperative actions used by the Create Agent wizard. */
export declare function useAgentActions(): {
    preview: (draft: AgentDraft) => Promise<ChangePreview>;
    createPullRequest: (draft: AgentDraft) => Promise<{
        url: string;
        status: string;
        reason?: string;
        effects: string[];
    }>;
    /** Render the Manager change-set. Pure; changes nothing. */
    previewManager: (draft: ManagerDraft) => Promise<ChangePreview>;
    /** Open the pull request for a Manager change. */
    createManagerPullRequest: (draft: ManagerDraft) => Promise<{
        url: string;
        status: string;
        reason?: string;
        effects: string[];
    }>;
    /**
     * Draft a system prompt from the form as it stands. Returns text only —
     * nothing is saved and no pull request is opened by this call.
     */
    draftPrompt: (context: PromptAssistRequest) => Promise<{
        prompt: string;
    }>;
    /** The curated built-in catalog, served by the runtime so it is not duplicated here. */
    avatarIcons: () => Promise<{
        icons: Array<{
            id: string;
            label: string;
            asset: string;
            fit: "cover" | "contain";
        }>;
    }>;
    /**
     * Check an upload before the operator reaches the review step, using the
     * SAME validation that will gate the change-set. A check in the browser
     * would be a second opinion, and not the one that counts.
     */
    validateAvatar: (upload: string) => Promise<{
        format: string;
        width: number;
        height: number;
        bytes: number;
    }>;
    /** Propose a prompt edit. Touches one file; the Agent document is untouched. */
    proposePrompt: (id: string, prompt: string) => Promise<{
        url?: string;
        status: string;
        reason?: string;
        effects: string[];
        branch: string;
    }>;
};
