/**
 * Overview (TDD §19).
 *
 * Three sections, each its own surface: the agents, one line about the
 * platform, and what has happened recently. It holds NO agent table — /agents
 * exists for inspecting and filtering, and repeating that here is what made
 * this screen read as a second administration console rather than as a home.
 *
 * Every value is counted from real configuration or from runs the runtime
 * recorded.
 */
export declare function OverviewPage(): import("react").JSX.Element;
