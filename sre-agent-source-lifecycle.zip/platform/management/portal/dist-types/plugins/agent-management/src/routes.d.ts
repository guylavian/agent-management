/**
 * Each sidebar section is its own page extension, so each needs a top-level
 * RouteRef. PageBlueprint does not accept a SubRouteRef.
 */
export declare const rootRouteRef: import("@backstage/frontend-plugin-api").RouteRef<undefined>;
export declare const agentsRouteRef: import("@backstage/frontend-plugin-api").RouteRef<undefined>;
export declare const managerRouteRef: import("@backstage/frontend-plugin-api").RouteRef<undefined>;
export declare const createAgentRouteRef: import("@backstage/frontend-plugin-api").RouteRef<undefined>;
export declare const permissionsRouteRef: import("@backstage/frontend-plugin-api").RouteRef<undefined>;
export declare const mcpServersRouteRef: import("@backstage/frontend-plugin-api").RouteRef<undefined>;
export declare const runsRouteRef: import("@backstage/frontend-plugin-api").RouteRef<undefined>;
