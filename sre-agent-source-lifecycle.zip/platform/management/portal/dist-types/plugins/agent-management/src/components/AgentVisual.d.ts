import type { AgentDraft } from '../api/types';
type Avatar = NonNullable<AgentDraft['avatar']>;
/**
 * "Agent visual" — the optional image an agent is shown with.
 *
 * Three states, and the third is a real one rather than a gap: an image
 * uploaded here, a built-in icon chosen from the catalog, or nothing at all,
 * in which case the agent renders as initials on its owning team's tone. Most
 * agents will stay in the third state and that is a finished design, not a
 * placeholder.
 *
 * Nothing on this control saves. An upload is held in the draft and travels in
 * the same change-set as the document that references it, so the pull request
 * either brings both or neither.
 */
export declare function AgentVisual(props: {
    name: string;
    owner: string;
    avatar?: Avatar | null;
    /** what the agent has on disk, so "Remove" can be distinguished from "unchanged" */
    existing?: {
        asset: string;
        fit: 'cover' | 'contain';
    };
    onChange: (next: Avatar | null | undefined) => void;
}): import("react").JSX.Element;
export {};
