/** Agents directory, agent detail and agent edit, mounted under the Agents nav entry. */
export declare function AgentsRoutes(): import("react").JSX.Element;
