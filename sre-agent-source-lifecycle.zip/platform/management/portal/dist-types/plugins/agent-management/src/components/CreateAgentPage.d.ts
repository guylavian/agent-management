/**
 * Create Agent (TDD §24–§30), and — given `agentId` — the edit form.
 *
 * ONE page, not a wizard. An agent is a configuration document, and the person
 * filling this in is reading a spec or an existing agent rather than being led
 * somewhere: paging five screens hid the shape of what was being built, made
 * fields impossible to compare, and put a Next button between an operator and
 * the value they came to change.
 *
 * Editing is the same form prefilled, because a second form would be a second
 * definition of what an Agent is and would be free to drift from this one. The
 * backend already treats a draft naming an existing Agent as an update.
 */
export declare function CreateAgentPage(props: {
    agentId?: string;
}): import("react").JSX.Element;
