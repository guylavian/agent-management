/**
 * Agents directory (TDD §20).
 *
 * Cards are the primary view because the question this page usually answers is
 * "which agent do I want", not "compare column six across ten rows". The table
 * stays one click away for the second question, which is a real one — it is
 * the only view where MCP and tool counts line up for comparison.
 */
export declare function AgentsPage(): import("react").JSX.Element;
