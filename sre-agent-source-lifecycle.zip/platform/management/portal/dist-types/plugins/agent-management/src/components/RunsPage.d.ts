/** Runs list (TDD §46). */
export declare function RunsPage(): import("react").JSX.Element;
/**
 * One run, as an execution trace (TDD §45).
 *
 * Four views of ONE event list, not four datasets. Flow reads the parent links
 * and shows the shape of the investigation; Timeline ignores them and shows the
 * order; Evidence and Details are filters. Nothing is computed in the browser
 * that the runtime did not record.
 */
export declare function RunDetailPage({ runId }: {
    runId: string;
}): import("react").JSX.Element;
