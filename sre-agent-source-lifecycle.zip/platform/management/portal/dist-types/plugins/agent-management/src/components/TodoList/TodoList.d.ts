export type TodoItem = {
    title: string;
    id: string;
    createdBy: string;
    createdAt: string;
};
export declare const TodoList: ({ todos }: {
    todos: TodoItem[];
}) => import("react").JSX.Element;
