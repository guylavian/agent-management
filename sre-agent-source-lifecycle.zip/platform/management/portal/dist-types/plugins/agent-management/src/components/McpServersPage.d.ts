/** MCP servers and their ToolHive posture (TDD §37/§38). */
export declare function McpServersPage(): import("react").JSX.Element;
