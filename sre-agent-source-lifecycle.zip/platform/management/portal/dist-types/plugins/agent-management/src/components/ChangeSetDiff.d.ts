import type { ChangeSetDiff as Diff } from '../api/types';
export declare function ChangeSetDiff({ diff }: {
    diff: Diff;
}): import("react").JSX.Element;
