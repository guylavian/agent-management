/** All Agent Management pages under one plugin route. */
export declare function AgentManagementRouter(): import("react").JSX.Element;
