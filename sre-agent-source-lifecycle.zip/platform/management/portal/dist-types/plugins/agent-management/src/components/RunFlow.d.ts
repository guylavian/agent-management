import type { RunNode } from '../api/types';
export declare function RunFlow({ nodes }: {
    nodes: RunNode[];
}): import("react").JSX.Element;
