/**
 * Agent → MCP permissions matrix (TDD §23). Selecting a cell opens the detailed
 * grant; the same data is readable from both directions.
 */
export declare function PermissionsPage(): import("react").JSX.Element;
