/** Agent detail (TDD §21/§22). */
export declare function AgentDetailPage({ agentId }: {
    agentId: string;
}): import("react").JSX.Element;
