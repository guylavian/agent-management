/** Runs list plus the execution graph for one run. */
export declare function RunsRoutes(): import("react").JSX.Element;
