/**
 * Product theme.
 *
 * Figtree is the UI typeface for everything, including the Backstage-rendered
 * chrome (sign-in, settings, catalog), so the shell does not visibly change
 * font when a user leaves the Agent Management screens.
 *
 * Technical values — model names, endpoints, client ids, audiences, versions,
 * timestamps and durations — use the system monospace stack instead, so an
 * operator can tell an identifier from prose at a glance.
 */
export declare const UI_FONT = "'Figtree', Helvetica, Arial, sans-serif";
export declare const MONO_FONT = "ui-monospace, Menlo, monospace";
export declare const themeModule: import("@backstage/frontend-plugin-api").FrontendModule;
