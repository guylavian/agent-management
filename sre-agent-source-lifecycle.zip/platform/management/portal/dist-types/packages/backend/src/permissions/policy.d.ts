import { type PolicyDecision } from '@backstage/plugin-permission-common';
import type { PermissionPolicy, PolicyQuery, PolicyQueryUser } from '@backstage/plugin-permission-node';
import type { Config } from '@backstage/config';
export interface AgentManagementPolicyOptions {
    /** entity refs (usually `group:default/<name>`) whose members may propose Agent changes */
    adminGroups: string[];
}
export declare function readPolicyOptions(config: Config): AgentManagementPolicyOptions;
export declare class AgentManagementPermissionPolicy implements PermissionPolicy {
    #private;
    constructor(options: AgentManagementPolicyOptions);
    handle(request: PolicyQuery, user?: PolicyQueryUser): Promise<PolicyDecision>;
}
export declare const agentManagementPermissionPolicy: import("@backstage/backend-plugin-api").BackendFeature;
